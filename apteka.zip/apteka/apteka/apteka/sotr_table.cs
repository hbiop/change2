﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace apteka
{
    public partial class sotr_table : Form
    {
        public sotr_table()
        {
            InitializeComponent();
            sotr Main = this.Owner as sotr;
        }

        private void btn_sort_Click(object sender, EventArgs e)
        {
            DataGridViewColumn Col = null;
            switch(listBox1.SelectedIndex)
            {
                case 0:
                    Col = dataGridViewTextBoxColumn2;
                    break;
                case 1:
                    Col = dataGridViewTextBoxColumn3;
                    break;
                case 2:
                    Col = dataGridViewTextBoxColumn4;
                    break;
                case 3:
                    Col = dataGridViewTextBoxColumn5;
                    break;
                case 4:
                    Col = dataGridViewTextBoxColumn6;
                    break;
                case 5:
                    Col = dataGridViewTextBoxColumn7;
                    break;
                case 6:
                    Col = dataGridViewTextBoxColumn8;
                    break;
                case 7:
                    Col = dataGridViewTextBoxColumn9;
                    break;
                case 8:
                    Col = dataGridViewTextBoxColumn10;
                    break;
                case 9:
                    Col = dataGridViewTextBoxColumn11;
                    break;
            }
            if(radioButton1.Checked)
            {
                информация_о_сотрудникахDataGridView.Sort(Col, ListSortDirection.Ascending);
            }
            else
            {
                информация_о_сотрудникахDataGridView.Sort(Col, ListSortDirection.Descending);
            }
        }

        private void btn_filtr_Click(object sender, EventArgs e)
        {
            информация_о_сотрудникахBindingSource.Filter = ($"Фамилия='" + comboBox1.Text + "'") ;
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            информация_о_сотрудникахBindingSource.Filter = "";
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void информация_о_сотрудникахBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_сотрудникахBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);

        }

        private void sotr_table_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.информация_о_сотрудниках". При необходимости она может быть перемещена или удалена.
            this.информация_о_сотрудникахTableAdapter.Fill(this._22_106_14_aptekaDataSet.информация_о_сотрудниках);

        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < информация_о_сотрудникахDataGridView.RowCount; i++)
            {
                информация_о_сотрудникахDataGridView.Rows[i].Selected = false;
                for (int j = 0; j < информация_о_сотрудникахDataGridView.ColumnCount; j++)
                {
                    if (информация_о_сотрудникахDataGridView.Rows[i].Cells[j].Value != null)
                    {
                        if (информация_о_сотрудникахDataGridView.Rows[i].Cells[j].Value.ToString().Contains(textBox1.Text))
                        {
                            информация_о_сотрудникахDataGridView.Rows[i].Selected = true;
                            break;
                        }
                    }
                
                }

            }
        }
    }
}
