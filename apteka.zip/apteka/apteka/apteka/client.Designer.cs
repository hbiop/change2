﻿namespace apteka
{
    partial class client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label имяLabel;
            System.Windows.Forms.Label фамилияLabel;
            System.Windows.Forms.Label отчествоLabel;
            System.Windows.Forms.Label эл__почтаLabel;
            System.Windows.Forms.Label номер_телефонаLabel;
            System.Windows.Forms.Label полLabel;
            System.Windows.Forms.Label номер_картыLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(client));
            this.label2 = new System.Windows.Forms.Label();
            this._22_106_14_aptekaDataSet = new apteka._22_106_14_aptekaDataSet();
            this.информация_о_клиентеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.информация_о_клиентеTableAdapter = new apteka._22_106_14_aptekaDataSetTableAdapters.информация_о_клиентеTableAdapter();
            this.tableAdapterManager = new apteka._22_106_14_aptekaDataSetTableAdapters.TableAdapterManager();
            this.информация_о_клиентеBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.информация_о_клиентеBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.имяTextBox = new System.Windows.Forms.TextBox();
            this.фамилияTextBox = new System.Windows.Forms.TextBox();
            this.отчествоTextBox = new System.Windows.Forms.TextBox();
            this.эл__почтаTextBox = new System.Windows.Forms.TextBox();
            this.полComboBox = new System.Windows.Forms.ComboBox();
            this.номер_картыTextBox = new System.Windows.Forms.TextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_last = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_pred = new System.Windows.Forms.Button();
            this.btn_first = new System.Windows.Forms.Button();
            имяLabel = new System.Windows.Forms.Label();
            фамилияLabel = new System.Windows.Forms.Label();
            отчествоLabel = new System.Windows.Forms.Label();
            эл__почтаLabel = new System.Windows.Forms.Label();
            номер_телефонаLabel = new System.Windows.Forms.Label();
            полLabel = new System.Windows.Forms.Label();
            номер_картыLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._22_106_14_aptekaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_клиентеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_клиентеBindingNavigator)).BeginInit();
            this.информация_о_клиентеBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // имяLabel
            // 
            имяLabel.AutoSize = true;
            имяLabel.Location = new System.Drawing.Point(322, 73);
            имяLabel.Name = "имяLabel";
            имяLabel.Size = new System.Drawing.Size(32, 13);
            имяLabel.TabIndex = 3;
            имяLabel.Text = "Имя:";
            имяLabel.Click += new System.EventHandler(this.имяLabel_Click);
            // 
            // фамилияLabel
            // 
            фамилияLabel.AutoSize = true;
            фамилияLabel.Location = new System.Drawing.Point(295, 99);
            фамилияLabel.Name = "фамилияLabel";
            фамилияLabel.Size = new System.Drawing.Size(59, 13);
            фамилияLabel.TabIndex = 4;
            фамилияLabel.Text = "Фамилия:";
            // 
            // отчествоLabel
            // 
            отчествоLabel.AutoSize = true;
            отчествоLabel.Location = new System.Drawing.Point(297, 125);
            отчествоLabel.Name = "отчествоLabel";
            отчествоLabel.Size = new System.Drawing.Size(57, 13);
            отчествоLabel.TabIndex = 6;
            отчествоLabel.Text = "Отчество:";
            // 
            // эл__почтаLabel
            // 
            эл__почтаLabel.AutoSize = true;
            эл__почтаLabel.Location = new System.Drawing.Point(297, 151);
            эл__почтаLabel.Name = "эл__почтаLabel";
            эл__почтаLabel.Size = new System.Drawing.Size(57, 13);
            эл__почтаLabel.TabIndex = 8;
            эл__почтаLabel.Text = "Эл  почта:";
            // 
            // номер_телефонаLabel
            // 
            номер_телефонаLabel.AutoSize = true;
            номер_телефонаLabel.Location = new System.Drawing.Point(258, 177);
            номер_телефонаLabel.Name = "номер_телефонаLabel";
            номер_телефонаLabel.Size = new System.Drawing.Size(96, 13);
            номер_телефонаLabel.TabIndex = 10;
            номер_телефонаLabel.Text = "Номер телефона:";
            // 
            // полLabel
            // 
            полLabel.AutoSize = true;
            полLabel.Location = new System.Drawing.Point(324, 203);
            полLabel.Name = "полLabel";
            полLabel.Size = new System.Drawing.Size(30, 13);
            полLabel.TabIndex = 12;
            полLabel.Text = "Пол:";
            // 
            // номер_картыLabel
            // 
            номер_картыLabel.AutoSize = true;
            номер_картыLabel.Location = new System.Drawing.Point(276, 230);
            номер_картыLabel.Name = "номер_картыLabel";
            номер_картыLabel.Size = new System.Drawing.Size(78, 13);
            номер_картыLabel.TabIndex = 14;
            номер_картыLabel.Text = "Номер карты:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(232, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(311, 31);
            this.label2.TabIndex = 2;
            this.label2.Text = "Информация о клиенте";
            // 
            // _22_106_14_aptekaDataSet
            // 
            this._22_106_14_aptekaDataSet.DataSetName = "_22_106_14_aptekaDataSet";
            this._22_106_14_aptekaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // информация_о_клиентеBindingSource
            // 
            this.информация_о_клиентеBindingSource.DataMember = "информация о клиенте";
            this.информация_о_клиентеBindingSource.DataSource = this._22_106_14_aptekaDataSet;
            // 
            // информация_о_клиентеTableAdapter
            // 
            this.информация_о_клиентеTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = apteka._22_106_14_aptekaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.информация_о_клиентеTableAdapter = this.информация_о_клиентеTableAdapter;
            this.tableAdapterManager.информация_о_лекарствеTableAdapter = null;
            this.tableAdapterManager.информация_о_поставкеTableAdapter = null;
            this.tableAdapterManager.Информация_о_поставщикахTableAdapter = null;
            this.tableAdapterManager.информация_о_продажахTableAdapter = null;
            this.tableAdapterManager.информация_о_сменеTableAdapter = null;
            this.tableAdapterManager.информация_о_сотрудникахTableAdapter = null;
            // 
            // информация_о_клиентеBindingNavigator
            // 
            this.информация_о_клиентеBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.информация_о_клиентеBindingNavigator.BindingSource = this.информация_о_клиентеBindingSource;
            this.информация_о_клиентеBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.информация_о_клиентеBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.информация_о_клиентеBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.информация_о_клиентеBindingNavigatorSaveItem});
            this.информация_о_клиентеBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.информация_о_клиентеBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.информация_о_клиентеBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.информация_о_клиентеBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.информация_о_клиентеBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.информация_о_клиентеBindingNavigator.Name = "информация_о_клиентеBindingNavigator";
            this.информация_о_клиентеBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.информация_о_клиентеBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.информация_о_клиентеBindingNavigator.TabIndex = 3;
            this.информация_о_клиентеBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // информация_о_клиентеBindingNavigatorSaveItem
            // 
            this.информация_о_клиентеBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.информация_о_клиентеBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("информация_о_клиентеBindingNavigatorSaveItem.Image")));
            this.информация_о_клиентеBindingNavigatorSaveItem.Name = "информация_о_клиентеBindingNavigatorSaveItem";
            this.информация_о_клиентеBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.информация_о_клиентеBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.информация_о_клиентеBindingNavigatorSaveItem.Click += new System.EventHandler(this.информация_о_клиентеBindingNavigatorSaveItem_Click);
            // 
            // имяTextBox
            // 
            this.имяTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_клиентеBindingSource, "Имя", true));
            this.имяTextBox.Location = new System.Drawing.Point(360, 70);
            this.имяTextBox.Name = "имяTextBox";
            this.имяTextBox.Size = new System.Drawing.Size(100, 20);
            this.имяTextBox.TabIndex = 4;
            this.имяTextBox.TextChanged += new System.EventHandler(this.имяTextBox_TextChanged);
            // 
            // фамилияTextBox
            // 
            this.фамилияTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_клиентеBindingSource, "Фамилия", true));
            this.фамилияTextBox.Location = new System.Drawing.Point(360, 96);
            this.фамилияTextBox.Name = "фамилияTextBox";
            this.фамилияTextBox.Size = new System.Drawing.Size(100, 20);
            this.фамилияTextBox.TabIndex = 5;
            // 
            // отчествоTextBox
            // 
            this.отчествоTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_клиентеBindingSource, "Отчество", true));
            this.отчествоTextBox.Location = new System.Drawing.Point(360, 122);
            this.отчествоTextBox.Name = "отчествоTextBox";
            this.отчествоTextBox.Size = new System.Drawing.Size(100, 20);
            this.отчествоTextBox.TabIndex = 7;
            // 
            // эл__почтаTextBox
            // 
            this.эл__почтаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_клиентеBindingSource, "Эл_ почта", true));
            this.эл__почтаTextBox.Location = new System.Drawing.Point(360, 148);
            this.эл__почтаTextBox.Name = "эл__почтаTextBox";
            this.эл__почтаTextBox.Size = new System.Drawing.Size(100, 20);
            this.эл__почтаTextBox.TabIndex = 9;
            // 
            // полComboBox
            // 
            this.полComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_клиентеBindingSource, "Пол", true));
            this.полComboBox.FormattingEnabled = true;
            this.полComboBox.Items.AddRange(new object[] {
            "мужской",
            "женский"});
            this.полComboBox.Location = new System.Drawing.Point(360, 200);
            this.полComboBox.Name = "полComboBox";
            this.полComboBox.Size = new System.Drawing.Size(121, 21);
            this.полComboBox.TabIndex = 13;
            // 
            // номер_картыTextBox
            // 
            this.номер_картыTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_клиентеBindingSource, "Номер карты", true));
            this.номер_картыTextBox.Location = new System.Drawing.Point(360, 227);
            this.номер_картыTextBox.Name = "номер_картыTextBox";
            this.номер_картыTextBox.Size = new System.Drawing.Size(100, 20);
            this.номер_картыTextBox.TabIndex = 15;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_клиентеBindingSource, "Номер телефона", true));
            this.maskedTextBox1.Location = new System.Drawing.Point(361, 175);
            this.maskedTextBox1.Mask = "8(000)-000-00-00";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox1.TabIndex = 16;
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_delete.Location = new System.Drawing.Point(485, 357);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(98, 27);
            this.btn_delete.TabIndex = 23;
            this.btn_delete.Text = "удалить";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_add.FlatAppearance.BorderSize = 0;
            this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_add.Location = new System.Drawing.Point(485, 324);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(98, 27);
            this.btn_add.TabIndex = 22;
            this.btn_add.Text = "добавить";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_save.Location = new System.Drawing.Point(327, 389);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(134, 27);
            this.btn_save.TabIndex = 21;
            this.btn_save.Text = "сохранить";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_last
            // 
            this.btn_last.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_last.FlatAppearance.BorderSize = 0;
            this.btn_last.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_last.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_last.Location = new System.Drawing.Point(193, 357);
            this.btn_last.Name = "btn_last";
            this.btn_last.Size = new System.Drawing.Size(108, 27);
            this.btn_last.TabIndex = 20;
            this.btn_last.Text = "последняя";
            this.btn_last.UseVisualStyleBackColor = false;
            this.btn_last.Click += new System.EventHandler(this.btn_last_Click);
            // 
            // btn_next
            // 
            this.btn_next.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_next.FlatAppearance.BorderSize = 0;
            this.btn_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_next.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_next.Location = new System.Drawing.Point(327, 357);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(134, 27);
            this.btn_next.TabIndex = 19;
            this.btn_next.Text = "следущая";
            this.btn_next.UseVisualStyleBackColor = false;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_pred
            // 
            this.btn_pred.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_pred.FlatAppearance.BorderSize = 0;
            this.btn_pred.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pred.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_pred.Location = new System.Drawing.Point(327, 324);
            this.btn_pred.Name = "btn_pred";
            this.btn_pred.Size = new System.Drawing.Size(134, 27);
            this.btn_pred.TabIndex = 18;
            this.btn_pred.Text = "предыдущая";
            this.btn_pred.UseVisualStyleBackColor = false;
            this.btn_pred.Click += new System.EventHandler(this.btn_pred_Click);
            // 
            // btn_first
            // 
            this.btn_first.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_first.FlatAppearance.BorderSize = 0;
            this.btn_first.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_first.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_first.Location = new System.Drawing.Point(193, 324);
            this.btn_first.Name = "btn_first";
            this.btn_first.Size = new System.Drawing.Size(108, 27);
            this.btn_first.TabIndex = 17;
            this.btn_first.Text = "первая";
            this.btn_first.UseVisualStyleBackColor = false;
            this.btn_first.Click += new System.EventHandler(this.btn_first_Click);
            // 
            // client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_last);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.btn_pred);
            this.Controls.Add(this.btn_first);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(номер_картыLabel);
            this.Controls.Add(this.номер_картыTextBox);
            this.Controls.Add(полLabel);
            this.Controls.Add(this.полComboBox);
            this.Controls.Add(номер_телефонаLabel);
            this.Controls.Add(эл__почтаLabel);
            this.Controls.Add(this.эл__почтаTextBox);
            this.Controls.Add(отчествоLabel);
            this.Controls.Add(this.отчествоTextBox);
            this.Controls.Add(фамилияLabel);
            this.Controls.Add(this.фамилияTextBox);
            this.Controls.Add(имяLabel);
            this.Controls.Add(this.имяTextBox);
            this.Controls.Add(this.информация_о_клиентеBindingNavigator);
            this.Controls.Add(this.label2);
            this.Name = "client";
            this.Text = "информация о клиенте";
            this.Load += new System.EventHandler(this.client_Load);
            ((System.ComponentModel.ISupportInitialize)(this._22_106_14_aptekaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_клиентеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_клиентеBindingNavigator)).EndInit();
            this.информация_о_клиентеBindingNavigator.ResumeLayout(false);
            this.информация_о_клиентеBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private _22_106_14_aptekaDataSet _22_106_14_aptekaDataSet;
        private System.Windows.Forms.BindingSource информация_о_клиентеBindingSource;
        private _22_106_14_aptekaDataSetTableAdapters.информация_о_клиентеTableAdapter информация_о_клиентеTableAdapter;
        private _22_106_14_aptekaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator информация_о_клиентеBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton информация_о_клиентеBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox имяTextBox;
        private System.Windows.Forms.TextBox фамилияTextBox;
        private System.Windows.Forms.TextBox отчествоTextBox;
        private System.Windows.Forms.TextBox эл__почтаTextBox;
        private System.Windows.Forms.ComboBox полComboBox;
        private System.Windows.Forms.TextBox номер_картыTextBox;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_last;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_pred;
        private System.Windows.Forms.Button btn_first;
    }
}