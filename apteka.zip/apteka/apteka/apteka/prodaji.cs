﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SqlClient;
using System.Reflection;
using System.Data.OleDb;

namespace apteka
{
    public partial class prodaji : Form
    {
        SqlConnection connection;
        public prodaji()
        {
            InitializeComponent();
            Form1 Main = this.Owner as Form1;
        }

        private void информация_о_продажахBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_продажахBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);

        }

        private void prodaji_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.информация_о_сотрудниках". При необходимости она может быть перемещена или удалена.
            this.информация_о_сотрудникахTableAdapter.Fill(this._22_106_14_aptekaDataSet.информация_о_сотрудниках);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.информация_о_лекарстве". При необходимости она может быть перемещена или удалена.
            this.информация_о_лекарствеTableAdapter.Fill(this._22_106_14_aptekaDataSet.информация_о_лекарстве);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.информация_о_клиенте". При необходимости она может быть перемещена или удалена.
            this.информация_о_клиентеTableAdapter.Fill(this._22_106_14_aptekaDataSet.информация_о_клиенте);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.информация_о_продажах". При необходимости она может быть перемещена или удалена.
            this.информация_о_продажахTableAdapter.Fill(this._22_106_14_aptekaDataSet.информация_о_продажах);

        }

        private void btn_first_Click(object sender, EventArgs e)
        {
            информация_о_продажахBindingSource.MoveFirst();
        }

        private void btn_pred_Click(object sender, EventArgs e)
        {
            информация_о_продажахBindingSource.MovePrevious();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            информация_о_продажахBindingSource.AddNew();
        }

        private void btn_last_Click(object sender, EventArgs e)
        {
            информация_о_продажахBindingSource.MoveLast();
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            информация_о_продажахBindingSource.MoveNext();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            информация_о_продажахBindingSource.RemoveCurrent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            var today  = DateTime.Today; 
            int month = today.Month;
            this.Validate();
            this.информация_о_продажахBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);
            
        }
    }
}
