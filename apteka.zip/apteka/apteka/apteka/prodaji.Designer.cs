﻿namespace apteka
{
    partial class prodaji
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label сумма_продажиLabel;
            System.Windows.Forms.Label дата_продажиLabel;
            System.Windows.Forms.Label iD_клиентаLabel;
            System.Windows.Forms.Label iD_лекарcтваLabel;
            System.Windows.Forms.Label iD_сотрудникаLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(prodaji));
            this.label2 = new System.Windows.Forms.Label();
            this._22_106_14_aptekaDataSet = new apteka._22_106_14_aptekaDataSet();
            this.информация_о_продажахBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.информация_о_продажахTableAdapter = new apteka._22_106_14_aptekaDataSetTableAdapters.информация_о_продажахTableAdapter();
            this.tableAdapterManager = new apteka._22_106_14_aptekaDataSetTableAdapters.TableAdapterManager();
            this.информация_о_клиентеTableAdapter = new apteka._22_106_14_aptekaDataSetTableAdapters.информация_о_клиентеTableAdapter();
            this.информация_о_лекарствеTableAdapter = new apteka._22_106_14_aptekaDataSetTableAdapters.информация_о_лекарствеTableAdapter();
            this.информация_о_сотрудникахTableAdapter = new apteka._22_106_14_aptekaDataSetTableAdapters.информация_о_сотрудникахTableAdapter();
            this.информация_о_продажахBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.информация_о_продажахBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.сумма_продажиTextBox = new System.Windows.Forms.TextBox();
            this.дата_продажиDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.iD_клиентаComboBox = new System.Windows.Forms.ComboBox();
            this.информацияОКлиентеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iD_лекарcтваComboBox = new System.Windows.Forms.ComboBox();
            this.информацияОЛекарствеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iD_сотрудникаComboBox = new System.Windows.Forms.ComboBox();
            this.информацияОСотрудникахBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_last = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_pred = new System.Windows.Forms.Button();
            this.btn_first = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            сумма_продажиLabel = new System.Windows.Forms.Label();
            дата_продажиLabel = new System.Windows.Forms.Label();
            iD_клиентаLabel = new System.Windows.Forms.Label();
            iD_лекарcтваLabel = new System.Windows.Forms.Label();
            iD_сотрудникаLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._22_106_14_aptekaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_продажахBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_продажахBindingNavigator)).BeginInit();
            this.информация_о_продажахBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОКлиентеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОЛекарствеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОСотрудникахBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // сумма_продажиLabel
            // 
            сумма_продажиLabel.AutoSize = true;
            сумма_продажиLabel.Location = new System.Drawing.Point(283, 84);
            сумма_продажиLabel.Name = "сумма_продажиLabel";
            сумма_продажиLabel.Size = new System.Drawing.Size(91, 13);
            сумма_продажиLabel.TabIndex = 5;
            сумма_продажиLabel.Text = "Сумма продажи:";
            // 
            // дата_продажиLabel
            // 
            дата_продажиLabel.AutoSize = true;
            дата_продажиLabel.Location = new System.Drawing.Point(291, 137);
            дата_продажиLabel.Name = "дата_продажиLabel";
            дата_продажиLabel.Size = new System.Drawing.Size(83, 13);
            дата_продажиLabel.TabIndex = 7;
            дата_продажиLabel.Text = "Дата продажи:";
            // 
            // iD_клиентаLabel
            // 
            iD_клиентаLabel.AutoSize = true;
            iD_клиентаLabel.Location = new System.Drawing.Point(309, 162);
            iD_клиентаLabel.Name = "iD_клиентаLabel";
            iD_клиентаLabel.Size = new System.Drawing.Size(65, 13);
            iD_клиентаLabel.TabIndex = 8;
            iD_клиентаLabel.Text = "ID клиента:";
            // 
            // iD_лекарcтваLabel
            // 
            iD_лекарcтваLabel.AutoSize = true;
            iD_лекарcтваLabel.Location = new System.Drawing.Point(297, 189);
            iD_лекарcтваLabel.Name = "iD_лекарcтваLabel";
            iD_лекарcтваLabel.Size = new System.Drawing.Size(77, 13);
            iD_лекарcтваLabel.TabIndex = 10;
            iD_лекарcтваLabel.Text = "ID лекарcтва:";
            // 
            // iD_сотрудникаLabel
            // 
            iD_сотрудникаLabel.AutoSize = true;
            iD_сотрудникаLabel.Location = new System.Drawing.Point(292, 110);
            iD_сотрудникаLabel.Name = "iD_сотрудникаLabel";
            iD_сотрудникаLabel.Size = new System.Drawing.Size(82, 13);
            iD_сотрудникаLabel.TabIndex = 11;
            iD_сотрудникаLabel.Text = "ID сотрудника:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(228, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(333, 31);
            this.label2.TabIndex = 4;
            this.label2.Text = "Информация о продажах";
            // 
            // _22_106_14_aptekaDataSet
            // 
            this._22_106_14_aptekaDataSet.DataSetName = "_22_106_14_aptekaDataSet";
            this._22_106_14_aptekaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // информация_о_продажахBindingSource
            // 
            this.информация_о_продажахBindingSource.DataMember = "информация о продажах";
            this.информация_о_продажахBindingSource.DataSource = this._22_106_14_aptekaDataSet;
            // 
            // информация_о_продажахTableAdapter
            // 
            this.информация_о_продажахTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = apteka._22_106_14_aptekaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.информация_о_клиентеTableAdapter = this.информация_о_клиентеTableAdapter;
            this.tableAdapterManager.информация_о_лекарствеTableAdapter = this.информация_о_лекарствеTableAdapter;
            this.tableAdapterManager.информация_о_поставкеTableAdapter = null;
            this.tableAdapterManager.Информация_о_поставщикахTableAdapter = null;
            this.tableAdapterManager.информация_о_продажахTableAdapter = this.информация_о_продажахTableAdapter;
            this.tableAdapterManager.информация_о_сменеTableAdapter = null;
            this.tableAdapterManager.информация_о_сотрудникахTableAdapter = this.информация_о_сотрудникахTableAdapter;
            // 
            // информация_о_клиентеTableAdapter
            // 
            this.информация_о_клиентеTableAdapter.ClearBeforeFill = true;
            // 
            // информация_о_лекарствеTableAdapter
            // 
            this.информация_о_лекарствеTableAdapter.ClearBeforeFill = true;
            // 
            // информация_о_сотрудникахTableAdapter
            // 
            this.информация_о_сотрудникахTableAdapter.ClearBeforeFill = true;
            // 
            // информация_о_продажахBindingNavigator
            // 
            this.информация_о_продажахBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.информация_о_продажахBindingNavigator.BindingSource = this.информация_о_продажахBindingSource;
            this.информация_о_продажахBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.информация_о_продажахBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.информация_о_продажахBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.информация_о_продажахBindingNavigatorSaveItem});
            this.информация_о_продажахBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.информация_о_продажахBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.информация_о_продажахBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.информация_о_продажахBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.информация_о_продажахBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.информация_о_продажахBindingNavigator.Name = "информация_о_продажахBindingNavigator";
            this.информация_о_продажахBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.информация_о_продажахBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.информация_о_продажахBindingNavigator.TabIndex = 5;
            this.информация_о_продажахBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // информация_о_продажахBindingNavigatorSaveItem
            // 
            this.информация_о_продажахBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.информация_о_продажахBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("информация_о_продажахBindingNavigatorSaveItem.Image")));
            this.информация_о_продажахBindingNavigatorSaveItem.Name = "информация_о_продажахBindingNavigatorSaveItem";
            this.информация_о_продажахBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.информация_о_продажахBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.информация_о_продажахBindingNavigatorSaveItem.Click += new System.EventHandler(this.информация_о_продажахBindingNavigatorSaveItem_Click);
            // 
            // сумма_продажиTextBox
            // 
            this.сумма_продажиTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_продажахBindingSource, "Сумма продажи", true));
            this.сумма_продажиTextBox.Location = new System.Drawing.Point(380, 81);
            this.сумма_продажиTextBox.Name = "сумма_продажиTextBox";
            this.сумма_продажиTextBox.Size = new System.Drawing.Size(100, 20);
            this.сумма_продажиTextBox.TabIndex = 6;
            // 
            // дата_продажиDateTimePicker
            // 
            this.дата_продажиDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.информация_о_продажахBindingSource, "Дата продажи", true));
            this.дата_продажиDateTimePicker.Location = new System.Drawing.Point(380, 133);
            this.дата_продажиDateTimePicker.Name = "дата_продажиDateTimePicker";
            this.дата_продажиDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.дата_продажиDateTimePicker.TabIndex = 8;
            // 
            // iD_клиентаComboBox
            // 
            this.iD_клиентаComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_продажахBindingSource, "ID клиента", true));
            this.iD_клиентаComboBox.DataSource = this.информацияОКлиентеBindingSource;
            this.iD_клиентаComboBox.DisplayMember = "ID клиента";
            this.iD_клиентаComboBox.FormattingEnabled = true;
            this.iD_клиентаComboBox.Location = new System.Drawing.Point(380, 159);
            this.iD_клиентаComboBox.Name = "iD_клиентаComboBox";
            this.iD_клиентаComboBox.Size = new System.Drawing.Size(121, 21);
            this.iD_клиентаComboBox.TabIndex = 9;
            // 
            // информацияОКлиентеBindingSource
            // 
            this.информацияОКлиентеBindingSource.DataMember = "информация о клиенте";
            this.информацияОКлиентеBindingSource.DataSource = this._22_106_14_aptekaDataSet;
            // 
            // iD_лекарcтваComboBox
            // 
            this.iD_лекарcтваComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_продажахBindingSource, "ID лекарcтва", true));
            this.iD_лекарcтваComboBox.DataSource = this.информацияОЛекарствеBindingSource;
            this.iD_лекарcтваComboBox.DisplayMember = "ID лекарства";
            this.iD_лекарcтваComboBox.FormattingEnabled = true;
            this.iD_лекарcтваComboBox.Location = new System.Drawing.Point(380, 186);
            this.iD_лекарcтваComboBox.Name = "iD_лекарcтваComboBox";
            this.iD_лекарcтваComboBox.Size = new System.Drawing.Size(121, 21);
            this.iD_лекарcтваComboBox.TabIndex = 11;
            // 
            // информацияОЛекарствеBindingSource
            // 
            this.информацияОЛекарствеBindingSource.DataMember = "информация о лекарстве";
            this.информацияОЛекарствеBindingSource.DataSource = this._22_106_14_aptekaDataSet;
            // 
            // iD_сотрудникаComboBox
            // 
            this.iD_сотрудникаComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_продажахBindingSource, "ID сотрудника", true));
            this.iD_сотрудникаComboBox.DataSource = this.информацияОСотрудникахBindingSource;
            this.iD_сотрудникаComboBox.DisplayMember = "ID сотрудника";
            this.iD_сотрудникаComboBox.FormattingEnabled = true;
            this.iD_сотрудникаComboBox.Location = new System.Drawing.Point(380, 107);
            this.iD_сотрудникаComboBox.Name = "iD_сотрудникаComboBox";
            this.iD_сотрудникаComboBox.Size = new System.Drawing.Size(121, 21);
            this.iD_сотрудникаComboBox.TabIndex = 12;
            // 
            // информацияОСотрудникахBindingSource
            // 
            this.информацияОСотрудникахBindingSource.DataMember = "информация о сотрудниках";
            this.информацияОСотрудникахBindingSource.DataSource = this._22_106_14_aptekaDataSet;
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_delete.Location = new System.Drawing.Point(493, 355);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(98, 27);
            this.btn_delete.TabIndex = 36;
            this.btn_delete.Text = "удалить";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_add.FlatAppearance.BorderSize = 0;
            this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_add.Location = new System.Drawing.Point(493, 322);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(98, 27);
            this.btn_add.TabIndex = 35;
            this.btn_add.Text = "добавить";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_save.Location = new System.Drawing.Point(335, 387);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(134, 27);
            this.btn_save.TabIndex = 34;
            this.btn_save.Text = "сохранить";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_last
            // 
            this.btn_last.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_last.FlatAppearance.BorderSize = 0;
            this.btn_last.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_last.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_last.Location = new System.Drawing.Point(201, 355);
            this.btn_last.Name = "btn_last";
            this.btn_last.Size = new System.Drawing.Size(108, 27);
            this.btn_last.TabIndex = 33;
            this.btn_last.Text = "последняя";
            this.btn_last.UseVisualStyleBackColor = false;
            this.btn_last.Click += new System.EventHandler(this.btn_last_Click);
            // 
            // btn_next
            // 
            this.btn_next.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_next.FlatAppearance.BorderSize = 0;
            this.btn_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_next.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_next.Location = new System.Drawing.Point(335, 355);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(134, 27);
            this.btn_next.TabIndex = 32;
            this.btn_next.Text = "следущая";
            this.btn_next.UseVisualStyleBackColor = false;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_pred
            // 
            this.btn_pred.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_pred.FlatAppearance.BorderSize = 0;
            this.btn_pred.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pred.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_pred.Location = new System.Drawing.Point(335, 322);
            this.btn_pred.Name = "btn_pred";
            this.btn_pred.Size = new System.Drawing.Size(134, 27);
            this.btn_pred.TabIndex = 31;
            this.btn_pred.Text = "предыдущая";
            this.btn_pred.UseVisualStyleBackColor = false;
            this.btn_pred.Click += new System.EventHandler(this.btn_pred_Click);
            // 
            // btn_first
            // 
            this.btn_first.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_first.FlatAppearance.BorderSize = 0;
            this.btn_first.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_first.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_first.Location = new System.Drawing.Point(201, 322);
            this.btn_first.Name = "btn_first";
            this.btn_first.Size = new System.Drawing.Size(108, 27);
            this.btn_first.TabIndex = 30;
            this.btn_first.Text = "первая";
            this.btn_first.UseVisualStyleBackColor = false;
            this.btn_first.Click += new System.EventHandler(this.btn_first_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(258, 241);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 37;
            this.label1.Text = "label1";
            // 
            // prodaji
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_last);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.btn_pred);
            this.Controls.Add(this.btn_first);
            this.Controls.Add(iD_сотрудникаLabel);
            this.Controls.Add(this.iD_сотрудникаComboBox);
            this.Controls.Add(iD_лекарcтваLabel);
            this.Controls.Add(this.iD_лекарcтваComboBox);
            this.Controls.Add(iD_клиентаLabel);
            this.Controls.Add(this.iD_клиентаComboBox);
            this.Controls.Add(дата_продажиLabel);
            this.Controls.Add(this.дата_продажиDateTimePicker);
            this.Controls.Add(сумма_продажиLabel);
            this.Controls.Add(this.сумма_продажиTextBox);
            this.Controls.Add(this.информация_о_продажахBindingNavigator);
            this.Controls.Add(this.label2);
            this.Name = "prodaji";
            this.Text = "prodaji";
            this.Load += new System.EventHandler(this.prodaji_Load);
            ((System.ComponentModel.ISupportInitialize)(this._22_106_14_aptekaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_продажахBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_продажахBindingNavigator)).EndInit();
            this.информация_о_продажахBindingNavigator.ResumeLayout(false);
            this.информация_о_продажахBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОКлиентеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОЛекарствеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОСотрудникахBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private _22_106_14_aptekaDataSet _22_106_14_aptekaDataSet;
        private System.Windows.Forms.BindingSource информация_о_продажахBindingSource;
        private _22_106_14_aptekaDataSetTableAdapters.информация_о_продажахTableAdapter информация_о_продажахTableAdapter;
        private _22_106_14_aptekaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator информация_о_продажахBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton информация_о_продажахBindingNavigatorSaveItem;
        private _22_106_14_aptekaDataSetTableAdapters.информация_о_клиентеTableAdapter информация_о_клиентеTableAdapter;
        private System.Windows.Forms.TextBox сумма_продажиTextBox;
        private System.Windows.Forms.DateTimePicker дата_продажиDateTimePicker;
        private System.Windows.Forms.ComboBox iD_клиентаComboBox;
        private System.Windows.Forms.ComboBox iD_лекарcтваComboBox;
        private System.Windows.Forms.BindingSource информацияОКлиентеBindingSource;
        private _22_106_14_aptekaDataSetTableAdapters.информация_о_лекарствеTableAdapter информация_о_лекарствеTableAdapter;
        private System.Windows.Forms.BindingSource информацияОЛекарствеBindingSource;
        private _22_106_14_aptekaDataSetTableAdapters.информация_о_сотрудникахTableAdapter информация_о_сотрудникахTableAdapter;
        private System.Windows.Forms.ComboBox iD_сотрудникаComboBox;
        private System.Windows.Forms.BindingSource информацияОСотрудникахBindingSource;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_last;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_pred;
        private System.Windows.Forms.Button btn_first;
        private System.Windows.Forms.Label label1;
    }
}