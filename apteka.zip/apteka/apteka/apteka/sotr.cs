﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace apteka
{
    public partial class sotr : Form
    {
        public sotr()
        {
            InitializeComponent();
            Form1 Main = this.Owner as Form1;
        }

        private void btn_first_Click(object sender, EventArgs e)
        {
            информация_о_сотрудникахBindingSource.MoveFirst();
        }

        private void btn_pred_Click(object sender, EventArgs e)
        {
            информация_о_сотрудникахBindingSource.MovePrevious();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            информация_о_сотрудникахBindingSource.AddNew();
        }

        private void btn_last_Click(object sender, EventArgs e)
        {
            информация_о_сотрудникахBindingSource.MoveLast();
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            информация_о_сотрудникахBindingSource.MoveNext();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            информация_о_сотрудникахBindingSource.RemoveCurrent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_сотрудникахBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sotr_table AddRec = new sotr_table();
            AddRec.Owner = this;
            AddRec.ShowDialog();
        }

        private void информация_о_сотрудникахBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_сотрудникахBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);

        }

        private void sotr_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.информация_о_сотрудниках". При необходимости она может быть перемещена или удалена.
            this.информация_о_сотрудникахTableAdapter.Fill(this._22_106_14_aptekaDataSet.информация_о_сотрудниках);

        }

        private void iD_сменыLabel_Click(object sender, EventArgs e)
        {

        }

        private void iD_сменыTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
