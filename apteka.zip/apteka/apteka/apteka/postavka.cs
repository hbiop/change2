﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace apteka
{
    public partial class postavka : Form
    {
        public postavka()
        {
            InitializeComponent();
            Form1 Main = this.Owner as Form1;
        }

        private void информация_о_поставкеBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_поставкеBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);

        }

        private void postavka_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.Информация_о_поставщиках". При необходимости она может быть перемещена или удалена.
            this.информация_о_поставщикахTableAdapter.Fill(this._22_106_14_aptekaDataSet.Информация_о_поставщиках);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.информация_о_поставке". При необходимости она может быть перемещена или удалена.
            this.информация_о_поставкеTableAdapter.Fill(this._22_106_14_aptekaDataSet.информация_о_поставке);

        }

        private void btn_first_Click(object sender, EventArgs e)
        {
            информация_о_поставкеBindingSource.MoveFirst();
        }

        private void btn_pred_Click(object sender, EventArgs e)
        {
            информация_о_поставкеBindingSource.MovePrevious();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            информация_о_поставкеBindingSource.AddNew();
        }

        private void btn_last_Click(object sender, EventArgs e)
        {
            информация_о_поставкеBindingSource.MoveLast();
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            информация_о_поставкеBindingSource.MoveNext();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            информация_о_поставкеBindingSource.RemoveCurrent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_поставкеBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);
        }
    }
}
