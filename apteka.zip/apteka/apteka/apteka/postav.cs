﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace apteka
{
    public partial class postav : Form
    {
        public postav()
        {
            InitializeComponent();
            Form1 Main = this.Owner as Form1;
        }

        private void информация_о_поставщикахBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_поставщикахBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);

        }

        private void postav_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.Информация_о_поставщиках". При необходимости она может быть перемещена или удалена.
            this.информация_о_поставщикахTableAdapter.Fill(this._22_106_14_aptekaDataSet.Информация_о_поставщиках);

        }

        private void btn_first_Click(object sender, EventArgs e)
        {
            информация_о_поставщикахBindingSource.MoveFirst();
        }

        private void btn_pred_Click(object sender, EventArgs e)
        {
            информация_о_поставщикахBindingSource.MovePrevious();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            информация_о_поставщикахBindingSource.AddNew();
        }

        private void btn_last_Click(object sender, EventArgs e)
        {
            информация_о_поставщикахBindingSource.MoveLast();
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            информация_о_поставщикахBindingSource.MoveNext();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            информация_о_поставщикахBindingSource.RemoveCurrent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_поставщикахBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);
        }
    }
}
