﻿namespace apteka
{
    partial class postavka
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(postavka));
            System.Windows.Forms.Label дата_поставкиLabel;
            System.Windows.Forms.Label iD_поставщикаLabel;
            System.Windows.Forms.Label цена_доставкиLabel;
            this.label2 = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_last = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_pred = new System.Windows.Forms.Button();
            this.btn_first = new System.Windows.Forms.Button();
            this._22_106_14_aptekaDataSet = new apteka._22_106_14_aptekaDataSet();
            this.информация_о_поставкеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.информация_о_поставкеTableAdapter = new apteka._22_106_14_aptekaDataSetTableAdapters.информация_о_поставкеTableAdapter();
            this.tableAdapterManager = new apteka._22_106_14_aptekaDataSetTableAdapters.TableAdapterManager();
            this.информация_о_поставкеBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.информация_о_поставкеBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.дата_поставкиDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.iD_поставщикаComboBox = new System.Windows.Forms.ComboBox();
            this.цена_доставкиTextBox = new System.Windows.Forms.TextBox();
            this.информацияОПоставщикахBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.информация_о_поставщикахTableAdapter = new apteka._22_106_14_aptekaDataSetTableAdapters.Информация_о_поставщикахTableAdapter();
            дата_поставкиLabel = new System.Windows.Forms.Label();
            iD_поставщикаLabel = new System.Windows.Forms.Label();
            цена_доставкиLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._22_106_14_aptekaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_поставкеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_поставкеBindingNavigator)).BeginInit();
            this.информация_о_поставкеBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОПоставщикахBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(214, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(324, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Информация о поставке";
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_delete.Location = new System.Drawing.Point(482, 384);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(98, 27);
            this.btn_delete.TabIndex = 29;
            this.btn_delete.Text = "удалить";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_add.FlatAppearance.BorderSize = 0;
            this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_add.Location = new System.Drawing.Point(482, 351);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(98, 27);
            this.btn_add.TabIndex = 28;
            this.btn_add.Text = "добавить";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_save.Location = new System.Drawing.Point(324, 416);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(134, 27);
            this.btn_save.TabIndex = 27;
            this.btn_save.Text = "сохранить";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_last
            // 
            this.btn_last.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_last.FlatAppearance.BorderSize = 0;
            this.btn_last.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_last.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_last.Location = new System.Drawing.Point(190, 384);
            this.btn_last.Name = "btn_last";
            this.btn_last.Size = new System.Drawing.Size(108, 27);
            this.btn_last.TabIndex = 26;
            this.btn_last.Text = "последняя";
            this.btn_last.UseVisualStyleBackColor = false;
            this.btn_last.Click += new System.EventHandler(this.btn_last_Click);
            // 
            // btn_next
            // 
            this.btn_next.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_next.FlatAppearance.BorderSize = 0;
            this.btn_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_next.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_next.Location = new System.Drawing.Point(324, 384);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(134, 27);
            this.btn_next.TabIndex = 25;
            this.btn_next.Text = "следущая";
            this.btn_next.UseVisualStyleBackColor = false;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_pred
            // 
            this.btn_pred.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_pred.FlatAppearance.BorderSize = 0;
            this.btn_pred.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pred.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_pred.Location = new System.Drawing.Point(324, 351);
            this.btn_pred.Name = "btn_pred";
            this.btn_pred.Size = new System.Drawing.Size(134, 27);
            this.btn_pred.TabIndex = 24;
            this.btn_pred.Text = "предыдущая";
            this.btn_pred.UseVisualStyleBackColor = false;
            this.btn_pred.Click += new System.EventHandler(this.btn_pred_Click);
            // 
            // btn_first
            // 
            this.btn_first.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_first.FlatAppearance.BorderSize = 0;
            this.btn_first.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_first.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_first.Location = new System.Drawing.Point(190, 351);
            this.btn_first.Name = "btn_first";
            this.btn_first.Size = new System.Drawing.Size(108, 27);
            this.btn_first.TabIndex = 23;
            this.btn_first.Text = "первая";
            this.btn_first.UseVisualStyleBackColor = false;
            this.btn_first.Click += new System.EventHandler(this.btn_first_Click);
            // 
            // _22_106_14_aptekaDataSet
            // 
            this._22_106_14_aptekaDataSet.DataSetName = "_22_106_14_aptekaDataSet";
            this._22_106_14_aptekaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // информация_о_поставкеBindingSource
            // 
            this.информация_о_поставкеBindingSource.DataMember = "информация о поставке";
            this.информация_о_поставкеBindingSource.DataSource = this._22_106_14_aptekaDataSet;
            // 
            // информация_о_поставкеTableAdapter
            // 
            this.информация_о_поставкеTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = apteka._22_106_14_aptekaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.информация_о_клиентеTableAdapter = null;
            this.tableAdapterManager.информация_о_лекарствеTableAdapter = null;
            this.tableAdapterManager.информация_о_поставкеTableAdapter = this.информация_о_поставкеTableAdapter;
            this.tableAdapterManager.Информация_о_поставщикахTableAdapter = this.информация_о_поставщикахTableAdapter;
            this.tableAdapterManager.информация_о_продажахTableAdapter = null;
            this.tableAdapterManager.информация_о_сменеTableAdapter = null;
            this.tableAdapterManager.информация_о_сотрудникахTableAdapter = null;
            // 
            // информация_о_поставкеBindingNavigator
            // 
            this.информация_о_поставкеBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.информация_о_поставкеBindingNavigator.BindingSource = this.информация_о_поставкеBindingSource;
            this.информация_о_поставкеBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.информация_о_поставкеBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.информация_о_поставкеBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.информация_о_поставкеBindingNavigatorSaveItem});
            this.информация_о_поставкеBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.информация_о_поставкеBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.информация_о_поставкеBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.информация_о_поставкеBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.информация_о_поставкеBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.информация_о_поставкеBindingNavigator.Name = "информация_о_поставкеBindingNavigator";
            this.информация_о_поставкеBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.информация_о_поставкеBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.информация_о_поставкеBindingNavigator.TabIndex = 30;
            this.информация_о_поставкеBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 15);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // информация_о_поставкеBindingNavigatorSaveItem
            // 
            this.информация_о_поставкеBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.информация_о_поставкеBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("информация_о_поставкеBindingNavigatorSaveItem.Image")));
            this.информация_о_поставкеBindingNavigatorSaveItem.Name = "информация_о_поставкеBindingNavigatorSaveItem";
            this.информация_о_поставкеBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.информация_о_поставкеBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.информация_о_поставкеBindingNavigatorSaveItem.Click += new System.EventHandler(this.информация_о_поставкеBindingNavigatorSaveItem_Click);
            // 
            // дата_поставкиLabel
            // 
            дата_поставкиLabel.AutoSize = true;
            дата_поставкиLabel.Location = new System.Drawing.Point(232, 92);
            дата_поставкиLabel.Name = "дата_поставкиLabel";
            дата_поставкиLabel.Size = new System.Drawing.Size(86, 13);
            дата_поставкиLabel.TabIndex = 30;
            дата_поставкиLabel.Text = "Дата поставки:";
            // 
            // дата_поставкиDateTimePicker
            // 
            this.дата_поставкиDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.информация_о_поставкеBindingSource, "Дата поставки", true));
            this.дата_поставкиDateTimePicker.Location = new System.Drawing.Point(324, 88);
            this.дата_поставкиDateTimePicker.Name = "дата_поставкиDateTimePicker";
            this.дата_поставкиDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.дата_поставкиDateTimePicker.TabIndex = 31;
            // 
            // iD_поставщикаLabel
            // 
            iD_поставщикаLabel.AutoSize = true;
            iD_поставщикаLabel.Location = new System.Drawing.Point(232, 117);
            iD_поставщикаLabel.Name = "iD_поставщикаLabel";
            iD_поставщикаLabel.Size = new System.Drawing.Size(86, 13);
            iD_поставщикаLabel.TabIndex = 31;
            iD_поставщикаLabel.Text = "ID поставщика:";
            // 
            // iD_поставщикаComboBox
            // 
            this.iD_поставщикаComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_поставкеBindingSource, "ID поставщика", true));
            this.iD_поставщикаComboBox.DataSource = this.информацияОПоставщикахBindingSource;
            this.iD_поставщикаComboBox.DisplayMember = "ID организации";
            this.iD_поставщикаComboBox.FormattingEnabled = true;
            this.iD_поставщикаComboBox.Location = new System.Drawing.Point(324, 114);
            this.iD_поставщикаComboBox.Name = "iD_поставщикаComboBox";
            this.iD_поставщикаComboBox.Size = new System.Drawing.Size(121, 21);
            this.iD_поставщикаComboBox.TabIndex = 32;
            // 
            // цена_доставкиLabel
            // 
            цена_доставкиLabel.AutoSize = true;
            цена_доставкиLabel.Location = new System.Drawing.Point(232, 144);
            цена_доставкиLabel.Name = "цена_доставкиLabel";
            цена_доставкиLabel.Size = new System.Drawing.Size(86, 13);
            цена_доставкиLabel.TabIndex = 32;
            цена_доставкиLabel.Text = "Цена доставки:";
            // 
            // цена_доставкиTextBox
            // 
            this.цена_доставкиTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_поставкеBindingSource, "Цена доставки", true));
            this.цена_доставкиTextBox.Location = new System.Drawing.Point(324, 141);
            this.цена_доставкиTextBox.Name = "цена_доставкиTextBox";
            this.цена_доставкиTextBox.Size = new System.Drawing.Size(100, 20);
            this.цена_доставкиTextBox.TabIndex = 33;
            // 
            // информацияОПоставщикахBindingSource
            // 
            this.информацияОПоставщикахBindingSource.DataMember = "Информация о поставщиках";
            this.информацияОПоставщикахBindingSource.DataSource = this._22_106_14_aptekaDataSet;
            // 
            // информация_о_поставщикахTableAdapter
            // 
            this.информация_о_поставщикахTableAdapter.ClearBeforeFill = true;
            // 
            // postavka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(800, 463);
            this.Controls.Add(цена_доставкиLabel);
            this.Controls.Add(this.цена_доставкиTextBox);
            this.Controls.Add(iD_поставщикаLabel);
            this.Controls.Add(this.iD_поставщикаComboBox);
            this.Controls.Add(дата_поставкиLabel);
            this.Controls.Add(this.дата_поставкиDateTimePicker);
            this.Controls.Add(this.информация_о_поставкеBindingNavigator);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_last);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.btn_pred);
            this.Controls.Add(this.btn_first);
            this.Controls.Add(this.label2);
            this.Name = "postavka";
            this.Text = "postavka";
            this.Load += new System.EventHandler(this.postavka_Load);
            ((System.ComponentModel.ISupportInitialize)(this._22_106_14_aptekaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_поставкеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_поставкеBindingNavigator)).EndInit();
            this.информация_о_поставкеBindingNavigator.ResumeLayout(false);
            this.информация_о_поставкеBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОПоставщикахBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_last;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_pred;
        private System.Windows.Forms.Button btn_first;
        private _22_106_14_aptekaDataSet _22_106_14_aptekaDataSet;
        private System.Windows.Forms.BindingSource информация_о_поставкеBindingSource;
        private _22_106_14_aptekaDataSetTableAdapters.информация_о_поставкеTableAdapter информация_о_поставкеTableAdapter;
        private _22_106_14_aptekaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator информация_о_поставкеBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton информация_о_поставкеBindingNavigatorSaveItem;
        private _22_106_14_aptekaDataSetTableAdapters.Информация_о_поставщикахTableAdapter информация_о_поставщикахTableAdapter;
        private System.Windows.Forms.DateTimePicker дата_поставкиDateTimePicker;
        private System.Windows.Forms.ComboBox iD_поставщикаComboBox;
        private System.Windows.Forms.TextBox цена_доставкиTextBox;
        private System.Windows.Forms.BindingSource информацияОПоставщикахBindingSource;
    }
}