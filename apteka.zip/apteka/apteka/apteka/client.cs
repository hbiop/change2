﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace apteka
{
    public partial class client : Form
    {
        public client()
        {
            InitializeComponent();
            Form1 Main = this.Owner as Form1;
        }

        private void информация_о_клиентеBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_клиентеBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);

        }

        private void client_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_22_106_14_aptekaDataSet.информация_о_клиенте". При необходимости она может быть перемещена или удалена.
            this.информация_о_клиентеTableAdapter.Fill(this._22_106_14_aptekaDataSet.информация_о_клиенте);

        }

        private void имяLabel_Click(object sender, EventArgs e)
        {

        }

        private void имяTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_first_Click(object sender, EventArgs e)
        {
            информация_о_клиентеBindingSource.MoveFirst();
        }

        private void btn_pred_Click(object sender, EventArgs e)
        {
            информация_о_клиентеBindingSource.MovePrevious();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            информация_о_клиентеBindingSource.AddNew();
        }

        private void btn_last_Click(object sender, EventArgs e)
        {
            информация_о_клиентеBindingSource.MoveLast();
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            информация_о_клиентеBindingSource.MoveNext();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            информация_о_клиентеBindingSource.RemoveCurrent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.информация_о_клиентеBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._22_106_14_aptekaDataSet);
        }
    }
}
