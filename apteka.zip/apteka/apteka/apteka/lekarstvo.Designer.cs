﻿namespace apteka
{
    partial class lekarstvo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label название_лекарстваLabel;
            System.Windows.Forms.Label тип_лекарстваLabel;
            System.Windows.Forms.Label производительLabel;
            System.Windows.Forms.Label ценаLabel;
            System.Windows.Forms.Label место_на_складеLabel;
            System.Windows.Forms.Label остаток_на_складеLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(lekarstvo));
            System.Windows.Forms.Label iD_поставкиLabel1;
            this.label2 = new System.Windows.Forms.Label();
            this._22_106_14_aptekaDataSet = new apteka._22_106_14_aptekaDataSet();
            this.информация_о_лекарствеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.информация_о_лекарствеTableAdapter = new apteka._22_106_14_aptekaDataSetTableAdapters.информация_о_лекарствеTableAdapter();
            this.tableAdapterManager = new apteka._22_106_14_aptekaDataSetTableAdapters.TableAdapterManager();
            this.информация_о_лекарствеBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.информация_о_лекарствеBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.название_лекарстваTextBox = new System.Windows.Forms.TextBox();
            this.тип_лекарстваTextBox = new System.Windows.Forms.TextBox();
            this.производительTextBox = new System.Windows.Forms.TextBox();
            this.ценаTextBox = new System.Windows.Forms.TextBox();
            this.место_на_складеTextBox = new System.Windows.Forms.TextBox();
            this.остаток_на_складеTextBox = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_last = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_pred = new System.Windows.Forms.Button();
            this.btn_first = new System.Windows.Forms.Button();
            this.iD_поставкиComboBox = new System.Windows.Forms.ComboBox();
            this.информацияОПоставкеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.информация_о_поставкеTableAdapter = new apteka._22_106_14_aptekaDataSetTableAdapters.информация_о_поставкеTableAdapter();
            название_лекарстваLabel = new System.Windows.Forms.Label();
            тип_лекарстваLabel = new System.Windows.Forms.Label();
            производительLabel = new System.Windows.Forms.Label();
            ценаLabel = new System.Windows.Forms.Label();
            место_на_складеLabel = new System.Windows.Forms.Label();
            остаток_на_складеLabel = new System.Windows.Forms.Label();
            iD_поставкиLabel1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this._22_106_14_aptekaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_лекарствеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_лекарствеBindingNavigator)).BeginInit();
            this.информация_о_лекарствеBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОПоставкеBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // название_лекарстваLabel
            // 
            название_лекарстваLabel.AutoSize = true;
            название_лекарстваLabel.Location = new System.Drawing.Point(252, 102);
            название_лекарстваLabel.Name = "название_лекарстваLabel";
            название_лекарстваLabel.Size = new System.Drawing.Size(116, 13);
            название_лекарстваLabel.TabIndex = 3;
            название_лекарстваLabel.Text = "Название лекарства:";
            // 
            // тип_лекарстваLabel
            // 
            тип_лекарстваLabel.AutoSize = true;
            тип_лекарстваLabel.Location = new System.Drawing.Point(283, 128);
            тип_лекарстваLabel.Name = "тип_лекарстваLabel";
            тип_лекарстваLabel.Size = new System.Drawing.Size(85, 13);
            тип_лекарстваLabel.TabIndex = 4;
            тип_лекарстваLabel.Text = "Тип лекарства:";
            // 
            // производительLabel
            // 
            производительLabel.AutoSize = true;
            производительLabel.Location = new System.Drawing.Point(279, 154);
            производительLabel.Name = "производительLabel";
            производительLabel.Size = new System.Drawing.Size(89, 13);
            производительLabel.TabIndex = 6;
            производительLabel.Text = "Производитель:";
            // 
            // ценаLabel
            // 
            ценаLabel.AutoSize = true;
            ценаLabel.Location = new System.Drawing.Point(332, 180);
            ценаLabel.Name = "ценаLabel";
            ценаLabel.Size = new System.Drawing.Size(36, 13);
            ценаLabel.TabIndex = 8;
            ценаLabel.Text = "Цена:";
            // 
            // место_на_складеLabel
            // 
            место_на_складеLabel.AutoSize = true;
            место_на_складеLabel.Location = new System.Drawing.Point(272, 206);
            место_на_складеLabel.Name = "место_на_складеLabel";
            место_на_складеLabel.Size = new System.Drawing.Size(96, 13);
            место_на_складеLabel.TabIndex = 10;
            место_на_складеLabel.Text = "Место на складе:";
            // 
            // остаток_на_складеLabel
            // 
            остаток_на_складеLabel.AutoSize = true;
            остаток_на_складеLabel.Location = new System.Drawing.Point(262, 232);
            остаток_на_складеLabel.Name = "остаток_на_складеLabel";
            остаток_на_складеLabel.Size = new System.Drawing.Size(106, 13);
            остаток_на_складеLabel.TabIndex = 12;
            остаток_на_складеLabel.Text = "Остаток на складе:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(192, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(339, 31);
            this.label2.TabIndex = 2;
            this.label2.Text = "Информация о лекарстве";
            // 
            // _22_106_14_aptekaDataSet
            // 
            this._22_106_14_aptekaDataSet.DataSetName = "_22_106_14_aptekaDataSet";
            this._22_106_14_aptekaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // информация_о_лекарствеBindingSource
            // 
            this.информация_о_лекарствеBindingSource.DataMember = "информация о лекарстве";
            this.информация_о_лекарствеBindingSource.DataSource = this._22_106_14_aptekaDataSet;
            // 
            // информация_о_лекарствеTableAdapter
            // 
            this.информация_о_лекарствеTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = apteka._22_106_14_aptekaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.информация_о_клиентеTableAdapter = null;
            this.tableAdapterManager.информация_о_лекарствеTableAdapter = this.информация_о_лекарствеTableAdapter;
            this.tableAdapterManager.информация_о_поставкеTableAdapter = null;
            this.tableAdapterManager.Информация_о_поставщикахTableAdapter = null;
            this.tableAdapterManager.информация_о_продажахTableAdapter = null;
            this.tableAdapterManager.информация_о_сменеTableAdapter = null;
            this.tableAdapterManager.информация_о_сотрудникахTableAdapter = null;
            // 
            // информация_о_лекарствеBindingNavigator
            // 
            this.информация_о_лекарствеBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.информация_о_лекарствеBindingNavigator.BindingSource = this.информация_о_лекарствеBindingSource;
            this.информация_о_лекарствеBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.информация_о_лекарствеBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.информация_о_лекарствеBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.информация_о_лекарствеBindingNavigatorSaveItem});
            this.информация_о_лекарствеBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.информация_о_лекарствеBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.информация_о_лекарствеBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.информация_о_лекарствеBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.информация_о_лекарствеBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.информация_о_лекарствеBindingNavigator.Name = "информация_о_лекарствеBindingNavigator";
            this.информация_о_лекарствеBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.информация_о_лекарствеBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.информация_о_лекарствеBindingNavigator.TabIndex = 3;
            this.информация_о_лекарствеBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // информация_о_лекарствеBindingNavigatorSaveItem
            // 
            this.информация_о_лекарствеBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.информация_о_лекарствеBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("информация_о_лекарствеBindingNavigatorSaveItem.Image")));
            this.информация_о_лекарствеBindingNavigatorSaveItem.Name = "информация_о_лекарствеBindingNavigatorSaveItem";
            this.информация_о_лекарствеBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.информация_о_лекарствеBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.информация_о_лекарствеBindingNavigatorSaveItem.Click += new System.EventHandler(this.информация_о_лекарствеBindingNavigatorSaveItem_Click);
            // 
            // название_лекарстваTextBox
            // 
            this.название_лекарстваTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_лекарствеBindingSource, "Название лекарства", true));
            this.название_лекарстваTextBox.Location = new System.Drawing.Point(374, 99);
            this.название_лекарстваTextBox.Name = "название_лекарстваTextBox";
            this.название_лекарстваTextBox.Size = new System.Drawing.Size(100, 20);
            this.название_лекарстваTextBox.TabIndex = 4;
            // 
            // тип_лекарстваTextBox
            // 
            this.тип_лекарстваTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_лекарствеBindingSource, "Тип лекарства", true));
            this.тип_лекарстваTextBox.Location = new System.Drawing.Point(374, 125);
            this.тип_лекарстваTextBox.Name = "тип_лекарстваTextBox";
            this.тип_лекарстваTextBox.Size = new System.Drawing.Size(100, 20);
            this.тип_лекарстваTextBox.TabIndex = 5;
            // 
            // производительTextBox
            // 
            this.производительTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_лекарствеBindingSource, "Производитель", true));
            this.производительTextBox.Location = new System.Drawing.Point(374, 151);
            this.производительTextBox.Name = "производительTextBox";
            this.производительTextBox.Size = new System.Drawing.Size(100, 20);
            this.производительTextBox.TabIndex = 7;
            // 
            // ценаTextBox
            // 
            this.ценаTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_лекарствеBindingSource, "Цена", true));
            this.ценаTextBox.Location = new System.Drawing.Point(374, 177);
            this.ценаTextBox.Name = "ценаTextBox";
            this.ценаTextBox.Size = new System.Drawing.Size(100, 20);
            this.ценаTextBox.TabIndex = 9;
            // 
            // место_на_складеTextBox
            // 
            this.место_на_складеTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_лекарствеBindingSource, "Место на складе", true));
            this.место_на_складеTextBox.Location = new System.Drawing.Point(374, 203);
            this.место_на_складеTextBox.Name = "место_на_складеTextBox";
            this.место_на_складеTextBox.Size = new System.Drawing.Size(100, 20);
            this.место_на_складеTextBox.TabIndex = 11;
            // 
            // остаток_на_складеTextBox
            // 
            this.остаток_на_складеTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_лекарствеBindingSource, "Остаток на складе", true));
            this.остаток_на_складеTextBox.Location = new System.Drawing.Point(374, 229);
            this.остаток_на_складеTextBox.Name = "остаток_на_складеTextBox";
            this.остаток_на_складеTextBox.Size = new System.Drawing.Size(100, 20);
            this.остаток_на_складеTextBox.TabIndex = 13;
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_delete.Location = new System.Drawing.Point(502, 364);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(98, 27);
            this.btn_delete.TabIndex = 22;
            this.btn_delete.Text = "удалить";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_add.FlatAppearance.BorderSize = 0;
            this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_add.Location = new System.Drawing.Point(502, 331);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(98, 27);
            this.btn_add.TabIndex = 21;
            this.btn_add.Text = "добавить";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_save.Location = new System.Drawing.Point(344, 396);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(134, 27);
            this.btn_save.TabIndex = 20;
            this.btn_save.Text = "сохранить";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_last
            // 
            this.btn_last.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_last.FlatAppearance.BorderSize = 0;
            this.btn_last.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_last.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_last.Location = new System.Drawing.Point(210, 364);
            this.btn_last.Name = "btn_last";
            this.btn_last.Size = new System.Drawing.Size(108, 27);
            this.btn_last.TabIndex = 19;
            this.btn_last.Text = "последняя";
            this.btn_last.UseVisualStyleBackColor = false;
            this.btn_last.Click += new System.EventHandler(this.btn_last_Click);
            // 
            // btn_next
            // 
            this.btn_next.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_next.FlatAppearance.BorderSize = 0;
            this.btn_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_next.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_next.Location = new System.Drawing.Point(344, 364);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(134, 27);
            this.btn_next.TabIndex = 18;
            this.btn_next.Text = "следущая";
            this.btn_next.UseVisualStyleBackColor = false;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_pred
            // 
            this.btn_pred.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_pred.FlatAppearance.BorderSize = 0;
            this.btn_pred.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pred.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_pred.Location = new System.Drawing.Point(344, 331);
            this.btn_pred.Name = "btn_pred";
            this.btn_pred.Size = new System.Drawing.Size(134, 27);
            this.btn_pred.TabIndex = 17;
            this.btn_pred.Text = "предыдущая";
            this.btn_pred.UseVisualStyleBackColor = false;
            this.btn_pred.Click += new System.EventHandler(this.btn_pred_Click);
            // 
            // btn_first
            // 
            this.btn_first.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btn_first.FlatAppearance.BorderSize = 0;
            this.btn_first.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_first.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_first.Location = new System.Drawing.Point(210, 331);
            this.btn_first.Name = "btn_first";
            this.btn_first.Size = new System.Drawing.Size(108, 27);
            this.btn_first.TabIndex = 16;
            this.btn_first.Text = "первая";
            this.btn_first.UseVisualStyleBackColor = false;
            this.btn_first.Click += new System.EventHandler(this.btn_first_Click);
            // 
            // iD_поставкиLabel1
            // 
            iD_поставкиLabel1.AutoSize = true;
            iD_поставкиLabel1.Location = new System.Drawing.Point(297, 258);
            iD_поставкиLabel1.Name = "iD_поставкиLabel1";
            iD_поставкиLabel1.Size = new System.Drawing.Size(71, 13);
            iD_поставкиLabel1.TabIndex = 22;
            iD_поставкиLabel1.Text = "ID поставки:";
            // 
            // iD_поставкиComboBox
            // 
            this.iD_поставкиComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.информация_о_лекарствеBindingSource, "ID поставки", true));
            this.iD_поставкиComboBox.DataSource = this.информацияОПоставкеBindingSource;
            this.iD_поставкиComboBox.DisplayMember = "ID поставки";
            this.iD_поставкиComboBox.FormattingEnabled = true;
            this.iD_поставкиComboBox.Location = new System.Drawing.Point(374, 255);
            this.iD_поставкиComboBox.Name = "iD_поставкиComboBox";
            this.iD_поставкиComboBox.Size = new System.Drawing.Size(121, 21);
            this.iD_поставкиComboBox.TabIndex = 23;
            // 
            // информацияОПоставкеBindingSource
            // 
            this.информацияОПоставкеBindingSource.DataMember = "информация о поставке";
            this.информацияОПоставкеBindingSource.DataSource = this._22_106_14_aptekaDataSet;
            // 
            // информация_о_поставкеTableAdapter
            // 
            this.информация_о_поставкеTableAdapter.ClearBeforeFill = true;
            // 
            // lekarstvo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(iD_поставкиLabel1);
            this.Controls.Add(this.iD_поставкиComboBox);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_last);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.btn_pred);
            this.Controls.Add(this.btn_first);
            this.Controls.Add(остаток_на_складеLabel);
            this.Controls.Add(this.остаток_на_складеTextBox);
            this.Controls.Add(место_на_складеLabel);
            this.Controls.Add(this.место_на_складеTextBox);
            this.Controls.Add(ценаLabel);
            this.Controls.Add(this.ценаTextBox);
            this.Controls.Add(производительLabel);
            this.Controls.Add(this.производительTextBox);
            this.Controls.Add(тип_лекарстваLabel);
            this.Controls.Add(this.тип_лекарстваTextBox);
            this.Controls.Add(название_лекарстваLabel);
            this.Controls.Add(this.название_лекарстваTextBox);
            this.Controls.Add(this.информация_о_лекарствеBindingNavigator);
            this.Controls.Add(this.label2);
            this.Name = "lekarstvo";
            this.Text = "информация о лекарстве";
            this.Load += new System.EventHandler(this.lekarstvo_Load);
            ((System.ComponentModel.ISupportInitialize)(this._22_106_14_aptekaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_лекарствеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.информация_о_лекарствеBindingNavigator)).EndInit();
            this.информация_о_лекарствеBindingNavigator.ResumeLayout(false);
            this.информация_о_лекарствеBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.информацияОПоставкеBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private _22_106_14_aptekaDataSet _22_106_14_aptekaDataSet;
        private System.Windows.Forms.BindingSource информация_о_лекарствеBindingSource;
        private _22_106_14_aptekaDataSetTableAdapters.информация_о_лекарствеTableAdapter информация_о_лекарствеTableAdapter;
        private _22_106_14_aptekaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator информация_о_лекарствеBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton информация_о_лекарствеBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox название_лекарстваTextBox;
        private System.Windows.Forms.TextBox тип_лекарстваTextBox;
        private System.Windows.Forms.TextBox производительTextBox;
        private System.Windows.Forms.TextBox ценаTextBox;
        private System.Windows.Forms.TextBox место_на_складеTextBox;
        private System.Windows.Forms.TextBox остаток_на_складеTextBox;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_last;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_pred;
        private System.Windows.Forms.Button btn_first;
        private System.Windows.Forms.ComboBox iD_поставкиComboBox;
        private System.Windows.Forms.BindingSource информацияОПоставкеBindingSource;
        private _22_106_14_aptekaDataSetTableAdapters.информация_о_поставкеTableAdapter информация_о_поставкеTableAdapter;
    }
}